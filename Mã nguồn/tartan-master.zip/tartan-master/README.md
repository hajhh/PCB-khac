Tartan
================================

![tartan](doc/img/tartan.jpg)

60% keyboard made by through hole components only. 

Atmega328p with VUSB on [QMK firmware](https://github.com/qmk/qmk_firmware).

[Build guide and bom is here](./doc)
[ビルドガイドとパーツリストはこちら](./doc)