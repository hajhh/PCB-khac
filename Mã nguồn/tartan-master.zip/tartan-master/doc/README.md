# Tartan # Through hole kit Build Guide

- Build Guide(en)   
Under construction! But almost same as [plaid](https://github.com/hsgw/plaid/tree/master/doc)
- [ビルドガイド(JP)](jp/)