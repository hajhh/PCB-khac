# DISCIPLINE

![discipline](./images/discipline-kicad.png)

[Build Guide](https://static1.squarespace.com/static/5c533d33348cd92b886e544d/t/5e9fbf9e58f1fb0b01f71a7c/1587527585202/DISCIPLINE+BUILD+GUIDE.pdf)

[QMK Toolbox Flashing Guide (Recommended)](https://static1.squarespace.com/static/5c533d33348cd92b886e544d/t/5d90521b1d22d176452c44a5/1569739293092/DISCIPLINE+FLASHING+GUIDE.pdf)

[Command Line Flashing Guide (Advanced)](https://static1.squarespace.com/static/5c533d33348cd92b886e544d/t/5d7f3c43fef3e33f1b03bfe2/1568619588036/DISCIPLINE+FLASHING+GUIDE+-+COMMAND+LINE.pdf)

[Bootloader](./bootloader)

[BOM (Parts List)](https://octopart.com/bom-tool/W4rybyut)