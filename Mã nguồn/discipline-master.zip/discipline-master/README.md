# DISCIPLINE
 65% keyboard assembled with only through hole components, including usb type-c

[BOM, Build Guide, and Flashing Information](./doc)

Kits available at [cftkb.com](https://www.cftkb.com)

**[Optional High Profile Lasercut Acrylic Case](./case)**

![discipline](./doc/images/discipline.jpeg)
![](./doc/images/discipline-kicad.png)
![](./doc/images/discipline-top.png)
![](./doc/images/discipline-bottom.png)