# mullet case

![](./images/mullet-case.jpg)