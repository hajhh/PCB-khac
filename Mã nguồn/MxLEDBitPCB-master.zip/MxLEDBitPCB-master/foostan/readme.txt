Forked by https://github.com/foostan/kbd
