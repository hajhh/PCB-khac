# BMEK High-profile Case

First Prototype made with an Isel ICP 4030:

![Case Assembled](https://i.imgur.com/5wR5hRO.jpg)

[Imgur Album](https://imgur.com/a/tHlaMWA)
