# MYSTERIUM
**TKL keyboard that can be entirely assembled using only through hole components, including usb type c**

**[BOM, Build Guide, and Flashing Information](./doc)**

**Kits available at [cftkb.com](https://www.cftkb.com)**

**[Optional High Profile Lasercut Acrylic Case](./case)**

![mysterium](./doc/images/mysterium.jpg)
![](./doc/images/mysterium-kicad.png)
![](./doc/images/mysterium-top.png)
![](./doc/images/mysterium-bottom.png)
![](./doc/images/mysterium-bottom-plate.png)