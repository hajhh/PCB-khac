# MYSTERIUM

![mysterium](./images/mysterium-kicad.png)

**[Build Guide](https://static1.squarespace.com/static/5c533d33348cd92b886e544d/t/5e5fc8299979957341bf18a8/1583335468613/MYSTERIUM+BUILD+GUIDE.pdf)**

**[QMK Toolbox Flashing Guide (Recommended)](https://static1.squarespace.com/static/5c533d33348cd92b886e544d/t/5e4771362bab65763e8d1e4c/1581740343418/MYSTERIUM+FLASHING+GUIDE.pdf)**

**[Command Line Flashing Guide (Advanced)](https://static1.squarespace.com/static/5c533d33348cd92b886e544d/t/5e33a3895318fc520982d4a1/1580442505724/MYSTERIUM+FLASHING+GUIDE+-+COMMAND+LINE.pdf)**

**[Bootloader](./bootloader)**

**[BOM (Parts List)](https://octopart.com/bom-tool/wr8C8imk)**